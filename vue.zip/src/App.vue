<template>
  <div id="app">
    <header-block></header-block>
    <body-block></body-block>
    <footer-block></footer-block>
  </div>
</template>

<script>
import BodyBlock from './components/body-block.vue'
import FooterBlock from './components/footer-block.vue'
import HeaderBlock from './components/header-block.vue'



export default {
  name: 'App',
  components: {
    HeaderBlock,
    BodyBlock,
    FooterBlock

  }
}
</script>

<style>
#app {
  width: min(100% - 2rem, 800px);
  margin-inline: auto;
  padding-top: 75px;
  /* font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale; */
  /* text-align: center; */
  /* color: #2c3e50; */
}
</style>
