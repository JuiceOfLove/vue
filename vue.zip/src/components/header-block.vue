<template>
    <header>
        <div class="header__inner">
            <div class="header__title"><span> {{ title }} </span></div>
            <div class="header__dark-theme">
                <span> {{ darkTheme }} </span>
                <!-- <svg viewBox="0 0 70 70" fill="white" stroke="black" xmlns="http://www.w3.org/2000/svg" width="150" height="150">
                <circle class="main__button" id="btn" cx="28.5" cy="37.5" r="4.5"/>
                <rect class="main__toggler" id="toggler" @click="toggleButton" x="21.5" y="32" width="22" height="11" rx="5.5" fill="black" fill-opacity="0"/>
                </svg> -->
            </div>
        </div>
    </header>

</template>

<script>
export default {
    name: 'header-block',
    data() {
        return {
            title: "Название проекта",
            darkTheme: "Темная тема",
            buttonOnX: 15,
            buttonOff: "Off",
        }
    },
    methods: {
        toggleButton: function toggle() {
            const toggler = document.querySelector('.main__button');
            toggler.classList.toggle('main__button--on');
        }
    }
}
</script>

<style scoped>

header {
    display: flex;
    justify-content: flex-end;
    padding-top: 5px;
    align-items: center;
    text-align: center;
    border: 2px solid black;


    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
}

.header__inner {
    display: flex;
    justify-content: space-between;
    width: 57%;
    align-items: center;
    /* margin: 0; */

}
/* .main__button {
    transition: 0.3s;
    fill: rgb(207, 0, 0);
}

.main__button--on {
    transition: 0.3s;
    fill: rgb(5, 202, 5);
    transform: translate(12%);
}

.main__icon {
    width: 50px;
    height: 50px;
} */
</style>