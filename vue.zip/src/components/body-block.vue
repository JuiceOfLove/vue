<template>
    <body>
        <div class="body__block"></div>
        <div class="body__block"></div>
    </body>
</template>

<script>
export default {
    name: 'body-block',
    data() {
        return {

        }
    }

}
</script>

<style scoped>
body {
    display: flex;
    justify-content: space-between;
    width: 100%;
    min-height: 500px ;
    align-items: center;
    text-align: center;
    /* border: 2px solid black; */
    margin: 0 auto;
    margin-top: 10px;
}

/* .block {
    border: 2px solid black;
}
. */

.body__block {
    border: 2px solid black;
    /* width: 100%; */
    min-height: 500px;
    min-width: 375px;
}
</style>